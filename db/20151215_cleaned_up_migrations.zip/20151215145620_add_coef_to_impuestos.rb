class AddCoefToImpuestos < ActiveRecord::Migration
  def change
    add_column :co_impuestos, :coef, :decimal, precision: 10, scale: 4, default: 0.00
  end
end
