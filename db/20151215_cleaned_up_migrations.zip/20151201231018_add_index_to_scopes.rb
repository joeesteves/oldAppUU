class AddIndexToScopes < ActiveRecord::Migration
  def change
  	rename_column :fw_scopes, :exlcuido, :excluido
  	add_index  :fw_scopes, :excluido, using: 'gin'  	
  	add_index  :fw_scopes, :incluido, using: 'gin'
  end
end
