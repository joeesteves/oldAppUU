class CreateBaModelos < ActiveRecord::Migration
  def change
    create_table :ba_modelos do |t|
      t.integer :estado, default: 1
      t.string :nombre
      t.text :desc

      t.timestamps null: false
    end
  end
end
