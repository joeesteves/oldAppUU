class CreateFwTarjetas < ActiveRecord::Migration
  def change
  	enable_extension 'hstore' unless extension_enabled?('hstore')
    create_table :fw_tarjetas do |t|
      t.string :estado
      t.string :titulo
      t.string :contenido
      t.hstore :formato

      t.timestamps null: false
    end
  end
end
