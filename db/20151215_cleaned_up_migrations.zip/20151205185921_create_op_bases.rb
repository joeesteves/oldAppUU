class CreateOpBases < ActiveRecord::Migration
  def change
    create_table :op_bases do |t|
      t.date :fecha
      t.integer :organizacion_id
      t.integer :empresa_id
      t.decimal :bruto, precision: 10, scale: 2
      t.decimal :impuesto, precision: 10, scale: 2
      t.decimal :total, precision: 10, scale: 2
      t.text :obs
      t.string :tipo
      t.integer :moneda_id
      t.string :comprobante

      t.timestamps null: false
    end
  end
end
