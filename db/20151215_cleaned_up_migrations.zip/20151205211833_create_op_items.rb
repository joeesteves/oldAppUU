class CreateOpItems < ActiveRecord::Migration
  def change
    create_table :op_items do |t|
      t.references :base, index: true
      t.integer :producto_id
      t.string :saldo_tipo
      t.decimal :valor, precision: 10, scale: 2
      t.text :obs

      t.timestamps null: false
    end
  end
end
