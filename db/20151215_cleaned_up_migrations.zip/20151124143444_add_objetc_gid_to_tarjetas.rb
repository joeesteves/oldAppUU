class AddObjetcGidToTarjetas < ActiveRecord::Migration
  def change
  	add_column :fw_tarjetas, :object_gid, :string
  end
end
