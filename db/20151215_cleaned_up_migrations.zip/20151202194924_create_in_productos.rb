class CreateInProductos < ActiveRecord::Migration
  def change
    create_table :in_productos do |t|
      t.string :nombre
      t.string :tipo
      t.references :unidad, index: true
      t.string :cta_compra_id
      t.string :cta_venta_id
      t.string :imp_compra_id
      t.string :imp_venta_id

      t.timestamps null: false
    end
     add_foreign_key "in_productos", "in_unidades", column: "unidad_id"
  end
end
