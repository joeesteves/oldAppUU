class CreateFwNotas < ActiveRecord::Migration
  def change
    create_table :fw_notas do |t|
      t.string :titulo
      t.text :contenido

      t.timestamps null: false
    end
  end
end
