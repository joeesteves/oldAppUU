class InToProducto < ActiveRecord::Migration
  def change
    rename_table :in_productos, :ba_productos
    rename_table :in_unidades, :pr_unidades
  end
end
