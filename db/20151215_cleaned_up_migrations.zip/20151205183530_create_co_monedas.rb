class CreateCoMonedas < ActiveRecord::Migration
  def change
    create_table :co_monedas do |t|
      t.string :nombre

      t.timestamps null: false
    end
  end
end
