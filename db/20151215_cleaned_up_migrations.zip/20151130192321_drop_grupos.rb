class DropGrupos < ActiveRecord::Migration
  def change
  	remove_column :ba_organizaciones, :grupo_id
  	drop_table :ba_grupos
  end
end
