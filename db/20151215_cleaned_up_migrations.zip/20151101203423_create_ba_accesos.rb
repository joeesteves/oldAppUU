class CreateBaAccesos < ActiveRecord::Migration
  def change
    create_table :ba_accesos do |t|
      t.references :usuario, index: true
      t.references :organizacion, index: true
      t.references :rol, index: true

      t.timestamps null: false
    end
    add_foreign_key :ba_accesos, :ba_organizaciones, column: :organizacion_id
    add_foreign_key :ba_accesos, :ba_usuarios, column: :usuario_id
    add_foreign_key :ba_accesos, :ba_roles, column: :rol_id

  end
end
