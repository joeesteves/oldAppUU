class CreateCoAsientos < ActiveRecord::Migration
  def change
    create_table :co_asientos do |t|
      t.date :fecha
      t.references :moneda, index: true
      t.decimal :cotizacion, precision: 10, scale: 2
      t.integer :empresa_id
      t.boolean :esgenerado

      t.timestamps null: false
    end
    add_foreign_key "co_asientos", "co_monedas", column: "moneda_id"
  end
end
