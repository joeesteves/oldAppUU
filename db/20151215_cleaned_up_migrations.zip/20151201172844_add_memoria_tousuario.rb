class AddMemoriaTousuario < ActiveRecord::Migration
  def change
  	add_column :ba_usuarios, :memoria, :hstore, null: false, default: ''
    add_index :ba_usuarios, :memoria, using: :gin

  end
end
