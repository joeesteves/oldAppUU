class AddModeloIdToTipos < ActiveRecord::Migration
  def change
  	add_column :ba_tipos, :modelo_id, :integer
  end
end
