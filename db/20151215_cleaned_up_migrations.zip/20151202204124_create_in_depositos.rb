class CreateInDepositos < ActiveRecord::Migration
  def change
    create_table :in_depositos do |t|
      t.string :nombre

      t.timestamps null: false
    end
  end
end
