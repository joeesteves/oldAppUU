class VolarDesc < ActiveRecord::Migration
  def change
  	remove_column :co_cuentas, :desc
  	remove_column :ba_organizaciones, :desc
  	rename_column :ba_roles, :desc, :descripcion
  end
end
