class CantidadPrecioImporteToOpItems < ActiveRecord::Migration
  def change
    add_column :op_items, :precio, :decimal, precision: 10, scale: 2
    add_column :op_items, :cantidad, :decimal, precision: 10, scale: 2
    add_column :op_items, :importe, :decimal, precision: 10, scale: 2
    remove_column :op_items, :valor
  end
end
