class CreateBaGrupos < ActiveRecord::Migration
  def change
    create_table :ba_grupos do |t|
      t.integer :estado
      t.string :nombre
      t.text :desc

      t.timestamps null: false
    end
  end
end
