class AddObjetoIdTotags < ActiveRecord::Migration
  def change
  	add_column :fw_tags, :objeto_id, :integer
  end
end
