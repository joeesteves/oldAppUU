class RmUnidades < ActiveRecord::Migration
  def change
  	remove_column :ba_productos, :unidad_id
  	drop_table :pr_unidades
  	add_column :ba_productos, :unidad, :string
  end
end
