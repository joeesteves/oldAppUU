class CreateBaTipos < ActiveRecord::Migration
  def change
    create_table :ba_tipos do |t|
      t.integer :estado
      t.string :codigo
      t.string :nombre
      t.text :desc

      t.timestamps null: false
    end
  end
end
