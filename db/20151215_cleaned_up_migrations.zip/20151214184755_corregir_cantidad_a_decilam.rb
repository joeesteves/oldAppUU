class CorregirCantidadADecilam < ActiveRecord::Migration
  def change
    change_column :op_items, :cantidad, :decimal, precision: 10, scale: 2, default: 1.00
  end
end
