class CreateBaRelaciones < ActiveRecord::Migration
  def change
    create_table :ba_relaciones do |t|
      t.integer :empresa_id
      t.integer :organizacion_id
      t.integer :tipo_id

      t.timestamps null: false
    end
  end
end
