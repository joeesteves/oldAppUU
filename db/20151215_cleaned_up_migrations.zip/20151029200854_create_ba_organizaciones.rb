class CreateBaOrganizaciones < ActiveRecord::Migration
  def change
    create_table :ba_organizaciones do |t|
      t.integer :estado
      t.string :nombre
      t.string :id_fiscal
      t.text :desc
      t.references :grupo, index: true
      t.timestamps null: false
    end
    add_foreign_key :ba_organizaciones, :ba_grupos, column: :grupo_id
  end
end
