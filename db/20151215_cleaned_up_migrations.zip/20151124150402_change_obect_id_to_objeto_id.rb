class ChangeObectIdToObjetoId < ActiveRecord::Migration
  def change
  	rename_column :fw_tarjetas, :object_gid, :objeto_gid
  end
end
