class CreateInUnidades < ActiveRecord::Migration
  def change
    create_table :in_unidades do |t|
      t.string :nombre

      t.timestamps null: false
    end
  end
end
