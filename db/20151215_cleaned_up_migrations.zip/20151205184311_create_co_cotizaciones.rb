class CreateCoCotizaciones < ActiveRecord::Migration
  def change
    create_table :co_cotizaciones do |t|
      t.date :fecha
      t.references :moneda, index: true
      t.decimal :valor, precision: 10, scale: 2

      t.timestamps null: false
    end
	add_foreign_key "co_cotizaciones", "co_monedas", column: "moneda_id"
  end
end
