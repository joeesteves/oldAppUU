class AddAlicuotaToImpuestos < ActiveRecord::Migration
  def change
    add_column :co_impuestos, :alicuota, :decimal, precision: 10, scale: 2, default: 0.00
    remove_column :co_impuestos, :tipo
  end
end
