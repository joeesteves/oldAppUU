class AddDefaultEstadoToOrganizacionYGrupo < ActiveRecord::Migration
  def change
  	change_column :ba_organizaciones, :estado, :integer, default: 1
  	change_column :ba_grupos, :estado, :integer, default: 1
  end
end
