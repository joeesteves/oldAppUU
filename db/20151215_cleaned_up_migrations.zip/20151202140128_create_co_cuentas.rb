class CreateCoCuentas < ActiveRecord::Migration
  def change
    create_table :co_cuentas do |t|
      t.string :codigo
      t.string :nombre
      t.text :desc
      t.string :tipo

      t.timestamps null: false
    end
  end
end
