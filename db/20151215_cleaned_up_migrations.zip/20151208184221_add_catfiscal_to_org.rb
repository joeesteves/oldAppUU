class AddCatfiscalToOrg < ActiveRecord::Migration
  def change
    add_column :ba_organizaciones, :cat_fiscal, :string
  end
end
