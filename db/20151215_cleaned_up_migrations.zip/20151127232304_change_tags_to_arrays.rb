class ChangeTagsToArrays < ActiveRecord::Migration
  def change
  	remove_column :fw_tags, :tags
  	add_column :fw_tags, :general, :string, array:true, default: []
  	add_index  :fw_tags, :general, using: 'gin'
  end
end
