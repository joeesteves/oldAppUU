class AddEmpresasPublicoToTag < ActiveRecord::Migration
  def change
  	add_column :fw_tags, :publico, :boolean, default: false
  	add_column :fw_tags, :incluido, :integer, array:true, default: []
  	add_column :fw_tags, :excluido, :integer, array:true, default: []
  	
  	add_index  :fw_tags, :excluido, using: 'gin'  	
  	add_index  :fw_tags, :incluido, using: 'gin'
  end
end
