class CreateCoItems < ActiveRecord::Migration
  def change
    create_table :co_items do |t|
      t.references :asiento, index: true
      t.date :venc
      t.integer :cuenta_id
      t.decimal :debe, precision: 10, scale: 2
      t.decimal :haber, precision: 10, scale: 2
      t.string :organizacion_id
      t.text :obs

      t.timestamps null: false
    end
    add_foreign_key "co_items", "co_asientos", column: "asiento_id"

  end
end
