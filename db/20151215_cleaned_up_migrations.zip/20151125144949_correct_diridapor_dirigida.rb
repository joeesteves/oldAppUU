class CorrectDiridaporDirigida < ActiveRecord::Migration
  def change
  	rename_column :fw_tarjetas, :dirida_a, :dirigida_a
  end
end
