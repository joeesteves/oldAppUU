class AddUsuariosATarjetas < ActiveRecord::Migration
  def change
  	add_column :fw_tarjetas, :creada_por, :integer
  	add_column :fw_tarjetas, :dirida_a, :integer, array:true
  end
end
