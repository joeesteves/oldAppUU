class UpdateSchema < ActiveRecord::Migration
  def change
  	drop_table :ba_tipos
  	drop_table :ba_modelos
  	drop_table :fw_nota
  end
end
