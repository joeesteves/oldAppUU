class CreateFwScopes < ActiveRecord::Migration
  def change
    create_table :fw_scopes do |t|
    	t.string :gid
    	t.integer :objeto_id
    	t.boolean :publico, default: false
    	t.integer :incluido, array:true, default: []
			t.integer :exlcuido, array:true, default: []
      t.timestamps null: false
    end
  end
end
