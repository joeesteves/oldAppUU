class ChangeTipoIdtoTipoEnRelacion < ActiveRecord::Migration
  def change
  	remove_column :ba_relaciones, :tipo_id
  	add_column :ba_relaciones, :tipo, :integer, index:true 
  end
end
