class ChangeOrganizacionIdToEmpresaIdEnAccesos < ActiveRecord::Migration
  def change
  	rename_column :ba_accesos, :organizacion_id, :empresa_id
  end
end
