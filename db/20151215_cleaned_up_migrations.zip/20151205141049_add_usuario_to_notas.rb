class AddUsuarioToNotas < ActiveRecord::Migration
  def change
  	add_column :fw_notas, :usuario_id, :integer
  end
end
