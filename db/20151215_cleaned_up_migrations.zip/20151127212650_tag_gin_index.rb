class TagGinIndex < ActiveRecord::Migration
  def change
    add_index :fw_tags, :tags, using: :gin
  end
end
