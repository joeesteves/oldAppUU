class FixProductoColumns < ActiveRecord::Migration
  def change
  	remove_column :ba_productos, :cta_compra_id
    remove_column :ba_productos,  :cta_venta_id
    remove_column :ba_productos,  :imp_compra_id
    remove_column :ba_productos,  :imp_venta_id

  	add_column :ba_productos, :cta_compra_id, :integer
    add_column :ba_productos,  :cta_venta_id, :integer
    add_column :ba_productos,  :imp_compra_id, :integer
    add_column :ba_productos,  :imp_venta_id, :integer

  end
end
