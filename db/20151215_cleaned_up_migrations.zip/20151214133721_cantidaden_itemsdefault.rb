class CantidadenItemsdefault < ActiveRecord::Migration
  def change
    change_column :op_items, :cantidad, :integer, default: 1
  end
end
