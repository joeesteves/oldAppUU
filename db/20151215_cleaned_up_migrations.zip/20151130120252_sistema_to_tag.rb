class SistemaToTag < ActiveRecord::Migration
  def change
  	add_column :fw_tags, :sistema, :string, array:true, default: []
  	add_index  :fw_tags, :sistema, using: 'gin'
  end
end
