class EstadoAIntegeEnTarjetas < ActiveRecord::Migration
  def change
    remove_column :fw_tarjetas, :estado
  	add_column :fw_tarjetas, :estado, :integer, default: 1
  end
end
