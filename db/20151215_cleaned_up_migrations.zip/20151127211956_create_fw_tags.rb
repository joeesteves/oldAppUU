class CreateFwTags < ActiveRecord::Migration
  def change
    create_table :fw_tags do |t|
      t.string :gid
      t.hstore :tags

      t.timestamps null: false
    end
  end
end
