class DiridaADefault < ActiveRecord::Migration
  def change
  	change_column :fw_tarjetas, :dirigida_a, :integer, array:true, default: []
  end
end
