class SetDefault1toEstadoTipos < ActiveRecord::Migration
  def change
  	change_column :ba_tipos, :estado, :integer, default: 1
  end
end
